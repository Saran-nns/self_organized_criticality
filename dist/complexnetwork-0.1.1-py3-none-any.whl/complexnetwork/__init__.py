import logging

__author__ = "Saranraj Nambusubramaniyan"
__version__ = "0.1.1"

logging.basicConfig(level=logging.INFO)
