class AvalancheExponentRelationship:
    def __init__(self):
        pass

    def lifetime(self):
        return NotImplementedError

    def size(self):
        return NotImplementedError

    def heigh_rescaling(self):
        return NotImplementedError

