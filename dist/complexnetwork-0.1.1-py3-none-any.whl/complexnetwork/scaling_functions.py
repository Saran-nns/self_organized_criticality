class ScalingFunctions(object):
    def __init__(self):
        pass

    def avalanche_size(self):
        return NotImplementedError

    def universal_scaling_function(self):
        return NotImplementedError

