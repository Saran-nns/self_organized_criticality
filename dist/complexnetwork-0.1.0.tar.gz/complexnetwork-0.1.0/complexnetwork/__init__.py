import logging

__author__ = "Saranraj Nambusubramaniyan"
__version__ = "0.1.0"

logging.basicConfig(level=logging.INFO)
